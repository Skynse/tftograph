# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['tftograph']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.22.1,<2.0.0', 'tensorflow>=2.7.0,<3.0.0']

entry_points = \
{'console_scripts': ['tftograph = tftograph.tftograph:main']}

setup_kwargs = {
    'name': 'tftograph',
    'version': '0.1.0',
    'description': 'Convert from keras model to pb graph file',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<3.11',
}


setup(**setup_kwargs)
